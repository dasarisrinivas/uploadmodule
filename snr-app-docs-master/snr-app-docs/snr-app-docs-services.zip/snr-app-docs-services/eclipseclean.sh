mvn eclipse:clean eclipse:eclipse -DWTPVersion=2.0
cd ../snr-mwl-domain
mvn eclipse:clean eclipse:eclipse -DWTPVersion=2.0
cd ../snr-mwl-commons
mvn eclipse:clean eclipse:eclipse -DWTPVersion=2.0
cd ../snr-mwl-db
mvn eclipse:clean eclipse:eclipse -DWTPVersion=2.0
cd ../snr-mwl-services
mvn eclipse:clean eclipse:eclipse -DWTPVersion=2.0

