package com.mwl.docs.services.util;

public class Constants {
	public static final boolean ROLLBACK = true;
}
