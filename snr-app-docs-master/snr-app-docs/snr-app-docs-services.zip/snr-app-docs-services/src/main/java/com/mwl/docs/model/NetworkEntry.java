package com.mwl.docs.model;

import com.google.api.client.util.Key;

/** 
 * @author jpotts
 */
public class NetworkEntry extends Entry {
	@Key
	public Network entry; 	
}
