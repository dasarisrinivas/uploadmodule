package com.mwl.docs.services;

import com.mwl.docs.domain.BusinessUnit;

public interface IDocMetaDataService {

	public String createBusinessUnit(BusinessUnit businessUnit) ;
	
}
