package com.mwl.docs.model;

import com.google.api.client.util.Key;

/** 
 * @author jpotts
 */
public class ContainerList {
	@Key
	public List<ContainerEntry> list;
}
