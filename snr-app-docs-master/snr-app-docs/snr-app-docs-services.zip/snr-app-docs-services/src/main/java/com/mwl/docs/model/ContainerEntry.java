package com.mwl.docs.model;

import com.google.api.client.util.Key;

/** 
 * @author jpotts
 */
public class ContainerEntry extends Entry {
	@Key
	public Container entry; 	
}
