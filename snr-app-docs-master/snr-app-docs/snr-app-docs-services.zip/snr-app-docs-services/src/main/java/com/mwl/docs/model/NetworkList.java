package com.mwl.docs.model;

import com.google.api.client.util.Key;

/** 
 * @author jpotts
 */
public class NetworkList {
	@Key
	public List<NetworkEntry> list;
}
