package com.mwl.docs.model;

/** 
 * @author jpotts
 */
public class Entry {

}
