package com.mwl.docs.model;

import com.google.api.client.util.Key;

/** 
 * @author jpotts
 */
public class SiteList {
	@Key
	public List<SiteEntry> list;
}
